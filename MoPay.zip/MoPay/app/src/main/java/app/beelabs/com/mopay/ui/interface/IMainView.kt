package app.beelabs.com.mopay.ui.`interface`

import app.beelabs.com.codebase.base.contract.IView

interface IMainView : IView {
}