package app.beelabs.com.mopay.ui.activity.product

import android.os.Bundle
import android.os.PersistableBundle
import app.beelabs.com.codebase.base.BaseActivity
import app.beelabs.com.mopay.R

class ScanQRActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scanqr_activity)
    }
}