package app.beelabs.com.mopay.model.pojo

class Order {

    var id: Int = 0
    var detailName: String? = null
    var detailPrice: Double = 0.0
}

