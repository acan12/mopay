package app.beelabs.com.mopay.ui.activity.trx

import android.os.Bundle
import app.beelabs.com.codebase.base.BaseActivity
import app.beelabs.com.mopay.R

class HistoryDetailActivity : BaseActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_detail)
    }
}