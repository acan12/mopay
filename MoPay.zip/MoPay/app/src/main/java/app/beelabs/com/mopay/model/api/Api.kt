package app.beelabs.com.mopay.model.api

class Api {
}