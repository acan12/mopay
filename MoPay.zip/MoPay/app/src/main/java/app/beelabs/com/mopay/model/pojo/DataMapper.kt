package app.beelabs.com.mopay.model.pojo


class DataMapper(){
    val order: List<Order>? = null
}

