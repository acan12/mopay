package app.beelabs.com.mopay.model.dao

import app.beelabs.com.codebase.base.BaseDao

class LoginDao : BaseDao() {

    interface ILoginDao {

    }
}