package app.beelabs.com.mopay.model.api

interface ApiService {
}