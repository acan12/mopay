package app.beelabs.com.mopay.presenter

import app.beelabs.com.codebase.base.BasePresenter
import app.beelabs.com.mopay.model.dao.LoginDao

class LoginPresenter : BasePresenter(), LoginDao.ILoginDao {

}