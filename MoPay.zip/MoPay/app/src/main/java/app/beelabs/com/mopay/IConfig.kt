package app.beelabs.com.mopay

interface IConfig {
    object APPCONFIG {
        val BASE_API_URL ="https://dodol.com"
    }



}